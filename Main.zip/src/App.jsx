import React from 'react';
import './App.css';
import Carl from './components/carl';
import Test from './components/Testimonials';
import Main from './components/Main';
import ChooseYourPick from './components/ChooseYourPick';
import HowKnowThyShelfWorks from './components/HowKnowThyShelfWorks';

const KnowThyShelf = () => {

  return (
    <>
      <Main/>
      <Carl/>
      <ChooseYourPick />
      <HowKnowThyShelfWorks/>
      <Test/>
    </>
  );
};
  export default KnowThyShelf;