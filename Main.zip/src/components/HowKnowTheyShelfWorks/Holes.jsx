import React from "react";

const Holes = () => {
    return(
        <>       
            <div className="holes hole-top"></div>
            <div className="holes hole-middle"></div>
            <div className="holes hole-bottom"></div>
        </>

    );
}

export default Holes;