import React from "react";
import Holes from "./Holes";

const Paper = ({head, para, paperClass}) => {
    const a = `paper ${paperClass}`;

    return (
    <div className={a}>
        <div className="lines">
            <div className="text">
                {head}<br /><br />
                {para}
            </div>
        </div>
        <Holes/>
    </div>
    );
}

export default Paper;