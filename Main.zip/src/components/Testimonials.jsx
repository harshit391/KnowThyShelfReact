import React from "react";

const Test = () => {
    return (
        <div id="canvas" style={{backgroundColor: "#f46060"}}>
        <div className="magazine-viewport">
            <div className="container">
                <div className="magazine">
                    <div ignore="1" className="next-button"></div>
                    <div ignore="1" className="previous-button"></div>
                </div>
            </div>
        </div>
    </div>
    )
}

export default Test;